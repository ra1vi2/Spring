package com.example.testjpa;

import java.util.List;

@Transactoinal
public class AccountDao {

    public void setTemplate(JpaTemplate template) {
        this.template = template;
    }

    JpaTemplate template;

    public void createAccount(int accountNumber, String owner, double balance){
        Account account = new Account( accountNumber,  owner,  balance);
        template.persist(account);
    }

    public void updateBalance(int accountNumber,double balance){
        Account account = new Account( accountNumber,  balance);
        account.setBalance(balance);
        template.merge(account);
    }

    public void delete(int accountNumber){
        Account account = template.find(Account.class,accountNumber);
        template.remove(account);
    }

    public List<Account> getAllAccount(){
        List<Account> accountList = template.find("select accountnumber from Accounts");
        return accountList;
    }

}
