package com.example.testjpa;

import java.util.List;

public class AcccountTest {
    public static void main(String args[]) {
        ApplicatioContext context = new ClassPathXmlApplicationContext("app.xml");
        AccountDao accountDao = context.getBean("accountdao", AccountDao.class);

        accountDao.createAccount(101, "ravi", 100.00);
        accountDao.updateBalance(101, 200.00);
        accountDao.createAccount(102, "random", 100.9);

        List<Account> accountList = accountDao.getAllAccount();
       for(int i=0;i<accountList.length.i++){
           System.out.println(account.getaccountNumber() + account.getBalance + account.getOwner());
       }

    accountDao.delete(102);
}
