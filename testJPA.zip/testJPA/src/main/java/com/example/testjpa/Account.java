package com.example.testjpa;

public class Account {
    private int accoutNUmber;

    public Account(int accountNumber, String owner, double balance) {
    }

    public Account(int accountNumber, double balance) {
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    private String owner;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    private double balance;
}
