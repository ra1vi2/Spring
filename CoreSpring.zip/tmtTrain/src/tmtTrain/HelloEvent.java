package tmtTrain;

public class HelloEvent {
	
	private String mesasge;

	public void getMesasge() {
	    System.out.println(mesasge);
	}

	public void setMesasge(String mesasge) {
		this.mesasge = mesasge;
	}
}
