package tmtTrain;

/*import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDao {
private JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}


public int saveEmployee(Employee e ) {
	String query = "insert into employees values('"+e.getId()+"', '"+e.getCity()+"')";
	return jdbcTemplate.update(query);
}


public int updateEployee(Employee e) {
	String query = "update employee set name='"+e.getName()+"' where id='"+e.getId()+"'";
	return jdbcTemplate.update(query);
}
}
	*/



