package tmtTrain;

public class BeanLifecycleExample {
	
	
	public void init() throws Exception{
		System.out.println("Bean Init method");
	}
	
	public void destroy() throws Exception{
		System.out.println("Bean destroyed");
	}
}
