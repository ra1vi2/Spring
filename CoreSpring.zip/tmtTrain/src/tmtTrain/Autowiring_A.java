package tmtTrain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/*
Autowiring : enables to inject dependency implicitly 
it internally uses(constructor and setter)

note : can't be used to inject primitive and String values


*/
public class Autowiring_A {

@Autowired	
@Qualifier("a")
Autowire_B b;

public Autowire_B getB() {
	return b;
}

@Autowired
public void setB(Autowire_B b) {
	this.b = b;
}

void print() {
	display();
	b.display();
	
}

void display() {
	//System.out.println("autoweire A");
}

public Autowiring_A() {
//	System.out.println("constructor A");
}
	

	
}
