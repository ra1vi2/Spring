package tmtTrain;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*
@Lazy : 
@Value : 

*/
@Configuration
public class Config {
	
	@Bean
	public Student student() {
		return new Student(101,"name" , address());
	}
	
	@Bean
	public Address address() {
		return new Address("city", "tate", "ountry");
	}

	//@Pre
	public void beforeDestroy() {
		
	}
}
