package tmtTrain;

public class Student {
	private int roll;
	private String name ;
	private Address address;

	
	public Student() {System.out.println("default");}
	
	public Student(int roll) {
		this.roll = roll;
	}
	
	public Student(String name) {
		this.name=name;
	}
	
	public Student(int roll, String name, Address address) {
		this.roll = roll;
		this.name = name;
		this.address = address;
	}
	
	public void display() {
		System.out.println(roll+ "  " + name);
		System.out.println(address.toString());
	}
}
