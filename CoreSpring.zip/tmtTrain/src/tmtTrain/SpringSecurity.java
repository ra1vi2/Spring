package tmtTrain;

/*
LDAP :  Lightweight Directory Access Protocol
Single sign-on
Access Authentication -> digest aa -> 
Web Form Authentication ..... 


Libraries -> spring-security 

*/
public class SpringSecurity {

}
