package tmtTrain;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class MainApplication {

	public static void main(String args[]) {
		//ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
	
		//context.start();
		
		/*
		 * HelloEvent obj = (HelloEvent)context.getBean("hello"); obj.getMesasge();
		 */
		
	//	CustomEventPublisher customEventPublisher = (CustomEventPublisher) context.getBean("custom");
	//	customEventPublisher.publish();
		
		//context.stop();
	
		
	/*	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.register(MyConfiguration.class);
		context.refresh();
		
		Mybean mb1 = context.getBean(Mybean.class);
		System.out.println(mb1.hashCode());
		
		Mybean mb2 = context.getBean(Mybean.class);
		System.out.println(mb2.hashCode());
		
		context.close(); */
		
		ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		
		HelloEvent obj = (HelloEvent)context.getBean("hello");
		obj.setMesasge("this is message from obj1");
		obj.getMesasge();
		
		HelloEvent obj2 = (HelloEvent)context.getBean("hello");
		obj2.getMesasge();
		
	}
	
}
