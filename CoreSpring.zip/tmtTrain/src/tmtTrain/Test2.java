package tmtTrain;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/*
bean lifecycle : managed by spring container 

program starts -> sprint container starts ->
 spring container creates instance of bean (as per the requirement)
  -> dependency is injected -> bean is destroyed
 

container started -> bean instantiated -> DI -> init() method -> utility method ->destroy() method 


 -> 



*/
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Resource resource = new ClassPathResource("app.xml"); BeanFactory factory =
		 * new XmlBeanFactory(resource);
		 * 
		 * //Student s = (Student)factory.getBean("std"); //s.display();
		 * 
		 * 
		 * Employee e = (Employee)factory.getBean("emp"); e.display();
		 */
		
	/*   ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("app.xml");	
		
		Employee e = (Employee)applicationContext.getBean("emp");
		e.display();
		
		applicationContext.close(); */
		
		
	/*	ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		Autowiring_A a = (Autowiring_A)context.getBean("a",Autowiring_A.class);
		
		a.display(); */
		
	}

}
