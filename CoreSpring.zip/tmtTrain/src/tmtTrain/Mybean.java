package tmtTrain;

public class Mybean {

	public Mybean() {
		System.out.println("Instance of mybean created");
	}
	
}
