package tmtTrain;

public class Autowire_B {
public Autowire_B() {
	//System.out.println("B constructir");
}
public void display() {
	//System.out.println("B autowire");
}

}
