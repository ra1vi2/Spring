package com.MVCValidation;

/*

put validation on model via annotations

 length, number ,regular expressions, custom validaitons 

@NotNull ->
@MIn ->
@Max -> 
@Size ->
@Pattern -> regilar expression
*/

public class BeanValidation {
	
@Size(min=1,message="Password is too small")	
private String Password;
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

@Max(1000,message="w")
private int id;
	
	
}
