package com.MVCValidation;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import spr2.Student;
import spr2.StudentDao;

@Controller
public class ValidationController {

	
	@RequestMapping("/validate")
	public String submit(@Valid @ModelAttribute("model"),BeanValidation bv, BindingResult br) {
		if(br.hasError()) {
			return "error";
		}
		else {
			return "welcome";
		}
	}
	
	@RequestMapping("/viewpage/{pageid}")
	public String displayPage(@PathVariable int pageid, Model model) {
		int total=10;
		if(pageid==1) {}
		else {
			pageid=(pageid-1)*(total+1);
		}
		StudentDao st;
		List<Student> list = st.getStudents();
		model.addAttribute("students",list);
		return "index";
	}

}
