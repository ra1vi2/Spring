package com.security.LoginReq;

import org.springframework.config.java.plugin.context.ComponentScan;
import org.springframework.context.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;  
import org.springframework.security.config.annotation.web.configuration.*;  
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;  
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@EnableWebSecurity
@ComponentScan("com.mycompany")
public class WebSecurityConfig implements WebSecurityConfigurerAdapter {

	@Bean
	public UserDetailsService userdetailsService() throws Exception{
		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
		manager.createUser(
				User.withDefaultPasswordEncoder().username("admin").password("1234").roles("USER").build());
		return manager;
	}

	
	
	protected void configure(HttpSecurity http) throws Exception{
		http.authorizeRequests().anyRequest().hasRole("ADMIN")
		.and().formLogin().and().httpBasic().and().logout().logoutUrl("/spseclogout").logoutSuccessUrl("/");
	}
	
	@RequestMapping("IsAdmin")
	@ResponseBody
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String checkRole() {
		return "admin";
	} 
	
}