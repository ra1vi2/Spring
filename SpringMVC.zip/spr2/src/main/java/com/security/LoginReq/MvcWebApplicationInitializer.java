package com.security.LoginReq;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import spr2.WebSecurityConfig;

public class MvcWebApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootCongifClasses(){
		return Class[] {WebSecurityConfig.class;}
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
	}
	
	@Override
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}

}
