package com.security.LoginReq;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.server.authentication.logout.SecurityContextServerLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class SecurityController {

	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping
	public String login() {
		return "login";
	}
	
	@RequestMapping(value="/spseclogout")
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(auth != null) {
			new SecurityContextServerLogoutHandler();
		}
		return "redirect:/";
	}
}
