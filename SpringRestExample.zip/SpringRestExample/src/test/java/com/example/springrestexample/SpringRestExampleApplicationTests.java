package com.example.springrestexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
