package com.example.springrestexample;

public class EmployeeNotFoundException extends RuntimeException{

    EmployeeNotFoundException(Long id){
        super("No Employee exists with ID : " + id );
    }

}
