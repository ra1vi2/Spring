package com.mycompany.myspring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class SecondController {
	
	@RequestMapping("/secControl")
	public String secondViewControl() {
		return "viewpage2";
	}

}
